# Jelly SMP Handbook v1.0

One Modonomicon book for Jelly SMP on Minecraft 26.3. Open **Contents** to pick a chapter. The four bookmarks on the left go to Contents, Productive Bees, Mekanism and Powah.

- **Productive Bees** includes the complete v1.1 Apiary progression and bee and nest charts. Open **Start here** in the bee tree to reach Breeding, Workshop, Genetics, Integrations and the collections.
- **Mekanism** covers osmium, first power, infusing, steel, circuits, cables and ore processing through oxygen purification.
- **Powah** covers initial parts, generators, FE distribution, the Energizing Orb, tier materials through Nitro and starter reactor setup.

The Mekanism and Powah pages are open for reference. Their map lines show suggested routes. Milestone markers track obtaining the listed item. Use JEI for additional recipes or alternate inputs.

## Install or upgrade

1. Replace the older Jelly SMP Bee Quests ZIP in the world’s `datapacks` directory with `Jelly SMP Handbook v1.0.zip`.
2. Restart the world. Your existing book becomes the **Jelly SMP Handbook**. To craft a copy, combine a Book and Honeycomb.
3. Open **Contents** via the first bookmark. When upgrading, the book may reopen to the last section you visited.

The internal book ID remains `jelly_bees:apiary`. All original bee entry IDs, progress facts, research nodes and hooks carry forward.

## Add a chapter

1. Add `categories/<chapter>.json` under `data/jelly_bees/modonomicon/books/apiary/`. Set its name, icon and sort number. Add `entry_to_open` to point the tab to its overview entry.
2. Add `entries/<chapter>/<entry>.json` in the same book folder. Match the category field to `jelly_bees:<chapter>` and the entry ID to `jelly_bees:<chapter>/<entry>`. Use `entry://<chapter>/<entry>` in page links. Use `category://<chapter>` when linking to the map or index.
3. Add a link to the chapter in `entries/handbook/contents.json`. Add a category-link entry to the map using the existing chapter links as a template. If the sidebar gets crowded, set `show_category_button` to `false` on subcategories and reach them through the parent chapter’s pages.
4. If you want tracked milestones, add facts, hooks and nodes in `data/jelly_bees/modonomicon/research/handbook/<chapter>/`. Point a guide entry’s `marker_condition` at its research node. Add an entry `condition` only when the player should unlock the page before reading it.

Validated against Jelly SMP pack revision 91ef1bc and its pinned Productive Bees, Mekanism, Mekanism Generators, Powah and Modonomicon builds.
