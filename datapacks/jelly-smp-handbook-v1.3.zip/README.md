# Jelly SMP Handbook v1.3

One Modonomicon book for Jelly SMP on Minecraft 26.3. Open **Contents** to pick a chapter. The bookmarks on the left go to Contents, Productive Bees, Bee Directory, Mekanism and Powah.

- **Productive Bees** includes the complete v1.1 Apiary progression and bee and nest charts. Use the compass bookmark for the **Bee Directory**, with direct links to all the bee quest maps and collections.
- **Mekanism** covers osmium, first power, infusing, steel, circuits, cables and ore processing through oxygen purification.
- **Powah** covers initial parts, generators, FE distribution, the Energizing Orb, tier materials through Nitro and starter reactor setup.

The Mekanism and Powah pages are open for reference. Their map lines show suggested routes. Milestone markers track obtaining the listed item. Use JEI for additional recipes or alternate inputs.

## Install or upgrade

1. Replace the older Handbook or Bee Quests ZIP in the world’s `datapacks` directory with `Jelly SMP Handbook v1.3.zip`.
2. Restart the world. Your existing book becomes the **Jelly SMP Handbook**. To craft a copy, combine a Book and Honeycomb.
3. Open **Contents** via the first bookmark. When upgrading, the book may reopen to the last section you visited.

The internal book ID remains `jelly_bees:apiary`. All original bee entry IDs, progress facts, research nodes and hooks carry forward.

## Bee navigation

Click the compass bookmark to move between the quest maps and collections. On the first spread of a collection, the links on the left open the Bee Directory, the Breeding quest map, and the other collections. Close a bee or nest entry with **X** to see its list again. After following a link, use the center back arrow on the entry to return to where you were.

## Breeding chart

Open **Bee Directory → Breeding chart**. Scroll down twice and drag to move around the complete 110-bee map. Gold nodes show every breeding pair in this pack, with direct lines from parents to offspring. Purple nodes are bees without breeding links. Hover for a name, or click to open the existing bee entry. Bee icons show a signature output, with example items for bees that make variable resources. Fluid and chemical outputs use representative items. Bees with no fixed resource keep their bee icons.

Open **Find a bee** for an alphabetized list and closer views of the 58 bees that have breeding connections. The **View breeding lineage** link in those bee entries also opens the closer view. Use the center back arrow after opening a bee from a map.

## Add a chapter

1. Add `categories/<chapter>.json` under `data/jelly_bees/modonomicon/books/apiary/`. Set its name, icon and sort number. Add `entry_to_open` to point the tab to its overview entry.
2. Add `entries/<chapter>/<entry>.json` in the same book folder. Match the category field to `jelly_bees:<chapter>` and the entry ID to `jelly_bees:<chapter>/<entry>`. Use `entry://<chapter>/<entry>` in page links. Use `category://<chapter>` when linking to the map or index.
3. Add a link to the chapter in `entries/handbook/contents.json`. Add a category-link entry to the map using the existing chapter links as a template. If the sidebar gets crowded, set `show_category_button` to `false` on subcategories and reach them through the parent chapter’s pages.
4. If you want tracked milestones, add facts, hooks and nodes in `data/jelly_bees/modonomicon/research/handbook/<chapter>/`. Point a guide entry’s `marker_condition` at its research node. Add an entry `condition` only when the player should unlock the page before reading it.

Validated against Jelly SMP pack revision 0670031 and its pinned Productive Bees, Mekanism, Mekanism Generators, Powah and Modonomicon builds.
