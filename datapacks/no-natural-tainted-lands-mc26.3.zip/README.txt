No Natural Tainted Lands - Minecraft 26.3 / Thaumaturge

INSTALLATION
Existing world: stop the server or close the world, copy the ZIP into that
world's datapacks folder, then start the server or reopen the world.
Singleplayer folder: <instance>/saves/<world>/datapacks/
Dedicated server folder: <server>/<level-name>/datapacks/

New world: add the ZIP in the Data Packs selection before creating the world.

With commands available, run /datapack list enabled to confirm it is enabled.
If it appears only in /datapack list available, enable it using its exact listed
identifier: /datapack enable "<listed identifier>" last
Then fully restart the server or close and reopen the world; /reload alone is
not sufficient to rebuild world-generation biome sources.

Keep this pack above other packs that override the same Tainted Lands region.

WHAT IT DOES
Overrides data/thaumaturge/lithostitched/region/tainted_lands.json and changes
only its region weight from 10 to 0. Lithostitched skips zero-weight regions.
The biome remains registered, but this natural Overworld injection is disabled.

Applies to newly generated terrain. Existing Tainted Lands are not removed.
Taint spread, flux outbreaks, tainted nodes and gameplay biome conversion remain
enabled according to the mod's existing settings. Other biome-generation mods
or datapacks could independently place this biome.

REQUIREMENTS AND SCOPE
Minecraft Java 26.3 (data pack format 121), Thaumaturge and its required
dependencies, including Lithostitched. Prepared November 5, 2026 against the
local RC8 region definition and Lithostitched 2.0.6 behavior.

The ZIP structure and JSON override were checked statically. No Minecraft client
was launched and this pack has not been tested in a running world.
The mod source, mod JAR and your existing worlds were not modified.
